﻿///HCR-An open sourece mobile robot platform
///This version follows the Protocols V0.11
/// Written by Ricky
///www.RoboticFan.com 
///Last updated on 13th September 2009
///Ver0.11
///You can redistribute this code under GPLV3 license
///You have to keep "HCR" and "RoboticFan.com"   



using System;
using System.Collections.Generic;
using System.Text;
using System.IO.Ports;



namespace HCR
{
    public class Core
    {


        public bool IsConnected = false;
        public int IRNUMBER = 7;
        public int[] IR = new int[7];
        public bool[] Bumper = new bool[3];

        internal byte[] Header = new byte[2] { 0x55, 0xaa };
        private System.IO.Ports.SerialPort serialPort;


        public delegate void DataReceivedEventHandler(object sender, DateTime timestamp);
        public event DataReceivedEventHandler DataReceived;


        public void Connect(SerialPortConfig config)
        {
            try
            {
                serialPort = new SerialPort();
                serialPort.BaudRate = config.BaudRate;
                serialPort.WriteTimeout = config.QueryTimeOut;
                serialPort.ReadTimeout = config.QueryTimeOut;
                serialPort.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort_DataReceived);
                serialPort.ReceivedBytesThreshold = 1;
                serialPort.PortName = config.PortName;
                Console.WriteLine("Trying to connect port: " + config.PortName);
                serialPort.Open();
                IsConnected = true;
            }
            catch(Exception e)
            {
                IsConnected = false;

            }

        }

        /// <summary>
        /// Disconnect HCR
        /// 断开HCR连接
        /// </summary>
        public void Disconnect()
        {
            try
            {
                if (serialPort.IsOpen)
                {
                    serialPort.DiscardInBuffer();
                    serialPort.DiscardOutBuffer();
                    serialPort.Close();
                    IsConnected = false;
                }
            }
            catch
            {
            }

        }

        #region Serial Port Data Structures

        public class SerialPortConfig
        {
            //Serial port configuration parameters

            //Baud rate is 115.2k with both jumpers
            private int _baudRate = 115200;
            private Parity _parity = Parity.None;
            private int _dataBits = 8;
            private StopBits _stopBits = StopBits.One;
            private string _portName = "COM1";

            private int _timeout = 1000;

            /// <summary>
            /// Serial Communications Port 
            /// </summary>

            public int CommPort
            {
                get
                {
                    try
                    {
                        return Int32.Parse(_portName.Substring(_portName.Length - 1));
                    }
                    catch (Exception)
                    {
                        // If we can't distinguish the port from the name, go negative
                        return -1;
                    }
                }
                set { _portName = "COM" + value.ToString(); }
            }


            public string PortName
            {
                get { return _portName; }
                set { _portName = value; }
            }

            /// <summary>
            /// Baud Rate
            /// </summary>

            public int BaudRate
            {
                get { return _baudRate; }
                set { _baudRate = value; }
            }

            /// <summary>
            /// Specifies the Parity bit for a Serial Port.
            /// </summary>

            public Parity Parity
            {
                get { return _parity; }
                set { _parity = value; }
            }


            public int DataBits
            {
                get { return _dataBits; }
                set { _dataBits = value; }
            }


            public StopBits StopBits
            {
                get { return _stopBits; }
                set { _stopBits = value; }
            }


            public int QueryTimeOut
            {
                get { return _timeout; }
                set { _timeout = value; }
            }
        }
        #endregion


        // Invoke the Changed event; called whenever list changes
        protected virtual void On_DataReceived(DateTime e)
        {
            if (DataReceived != null)
                DataReceived(this, e);

        }

        //Set Motor Power 
        //设置电机功率

        public void SetMotorPower(int M1P, int M2P)
        {
            if (IsConnected)
            {
                byte[] cmd = new byte[9];

                cmd[0] = Header[0];
                cmd[1] = Header[1];
                cmd[2] = 0x01;
                cmd[3] = 0x02;
                cmd[4] = 0x01;

                if (M1P > 0)
                {
                    M1P = Math.Min(99, M1P);
                    M1P = Math.Max(35, M1P);

                }
                else
                {
                    if (M1P != 0)
                    {
                        M1P = Math.Max(-99, M1P);
                        M1P = Math.Min(-35, M1P);
                    }
                }

                if (M2P > 0)
                {
                    M2P = Math.Min(99, M2P);
                    M2P = Math.Max(35, M2P);
                }
                else
                {
                    if (M2P != 0)
                    {
                        M2P = Math.Max(-99, M2P);
                        M2P = Math.Min(-35, M2P);
                    }
                }

                M1P = -M1P;
                M2P = -M2P;

                cmd[5] = (byte)(int)((128 * M1P / 100) + 127);
                cmd[6] = (byte)(int)((128 * M2P / 100) + 127);

                for (int i = 0; i < cmd.Length - 2; i++)
                {
                    cmd[7] += cmd[i];
                }

                cmd[8] = 0x0a;

                if (serialPort.IsOpen && serialPort.BytesToWrite == 0)
                {
                    serialPort.Write(cmd, 0, cmd.Length);
                }
            }


        }
        /// <summary>
        /// Read InfraRed Sensor
        /// 读取红外传感器
        /// </summary>
        public void ReadIR()
        {
            if (IsConnected)
            {
                byte[] cmd = new byte[8];
                cmd[0] = Header[0];
                cmd[1] = Header[1];
                cmd[2] = 0x01;
                cmd[3] = 0x01;
                cmd[4] = 0x12;
                cmd[5] = 0xff;
                for (int i = 0; i < cmd.Length - 2; i++)
                {
                    cmd[6] += cmd[i];
                }

                cmd[7] = 0x0a;

                if (serialPort.IsOpen && serialPort.BytesToWrite == 0)
                {
                    serialPort.Write(cmd, 0, cmd.Length);
                }
            }
        }
        /// <summary>
        /// Read Bumper Sensor
        /// 读取碰撞传感器
        /// </summary>
        public void ReadBumper()
        {
            if (IsConnected)
            {

                byte[] cmd = new byte[8];
                cmd[0] = Header[0];
                cmd[1] = Header[1];
                cmd[2] = 0x01;
                cmd[3] = 0x01;
                cmd[4] = 0x11;
                cmd[5] = 0xff;
                for (int i = 0; i < cmd.Length - 2; i++)
                {
                    cmd[6] += cmd[i];
                }

                cmd[7] = 0x0a;

                if (serialPort.IsOpen && serialPort.BytesToWrite == 0)
                {
                    serialPort.Write(cmd, 0, cmd.Length);
                }
            }
        }



        public void TurnOnLight()
        {

            if (IsConnected)
            {
                byte[] cmd = new byte[8];
                cmd[0] = Header[0];
                cmd[1] = Header[1];
                cmd[2] = 0x01;
                cmd[3] = 0x01;
                cmd[4] = 0x14;
                cmd[5] = 0xff;
                for (int i = 0; i < cmd.Length - 2; i++)
                {
                    cmd[6] += cmd[i];
                }

                cmd[7] = 0x0a;

                if (serialPort.IsOpen && serialPort.BytesToWrite == 0)
                {
                    serialPort.Write(cmd, 0, cmd.Length);
                }
            }
        }


        private void serialPort_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {

            try
            {

                byte[] response = new byte[20];
                int i = 0;

                byte data = (byte)(serialPort.ReadByte());
                if (data == 0x55)
                {
                    response[0] = data;

                    if (serialPort.BytesToRead > 0)
                    {
                        data = (byte)(serialPort.ReadByte());

                        if (data == 0xaa)
                        {
                            response[1] = data;
                            while (data != 0x0a)
                            {
                                if (serialPort.BytesToRead > 0)
                                {
                                    data = (byte)serialPort.ReadByte();
                                    response[i + 2] = data;
                                    i++;
                                }
                            }

                            serialPort.DiscardInBuffer();

                            ParseResponse(response, i);


                        }


                    }
                }






            }
            catch (Exception error)
            {

            }

        }

    

        private void ParseResponse(byte[] data, int length)
        {
            switch (data[4])
            {
                case 0x11:
                    {
                        byte bumper= data[5];

                        Bumper=new bool[3]{false,false,false};

                        switch (bumper)
                        {
                            case 0x03: //left bumper has been triggered
                                {
                                    Bumper[0] = true;
                                    Bumper[1] = false;
                                    Bumper[2] = false;

                                    break;

                                }
                            case 0x05://center bumper has been triggered
                                {
                                    Bumper[0] = false;
                                    Bumper[1] = true;
                                    Bumper[2] = false;

                                    break;

                                }
                            case 0x06: //right bumper has been triggered
                                {
                                    Bumper[0] = false;
                                    Bumper[1] = false;
                                    Bumper[2] = true;

                                    break;

                                }

                            case 0x01: //left and center bumper has been triggered
                                {
                                    Bumper[0] = true;
                                    Bumper[1] = true;
                                    Bumper[2] = false;

                                    break;

                                }


                            case 0x00: //all bumpers has been triggered
                                {
                                    Bumper[0] = true;
                                    Bumper[1] = true;
                                    Bumper[2] = true;

                                    break;

                                }

                            case 0x02: //left and right bumpers have been triggered
                                {
                                    Bumper[0] = true;
                                    Bumper[1] = false;
                                    Bumper[2] = true;

                                    break;

                                }

                            case 0x04: //center and right bumpers have been triggered
                                {
                                    Bumper[0] = false;
                                    Bumper[1] = true;
                                    Bumper[2] = true;

                                    break;

                                }

                            case 0x07: //No bumpers have been triggered
                                {
                                    Bumper[0] = false;
                                    Bumper[1] = false;
                                    Bumper[2] = false;

                                    break;

                                }

                        }

                        break;
                    }
                case 0x12:
                    {
                        IRNUMBER = (int)data[3];
                        IR = new int[IRNUMBER];
                        for (int i = 0; i < IRNUMBER; i++)
                        {
                            IR[i] = (int)data[5 + i];
                        }

                        break;
                    }
            }

            On_DataReceived(DateTime.Now);
      
        }

    }
}
